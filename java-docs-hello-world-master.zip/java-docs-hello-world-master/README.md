---
page_type: sample
languages:
- java
products:
- azure
description: "This sample demonstarates a Hello World app for Azure App Service Linux"
urlFragment: java-docs-hello-world
---

# Azure App Service on Linux

## Java HelloWorld

This sample demonstarates a Hello World app for Azure App Service Linux

## Contributing

This project has adopted the Microsoft Open Source Code of Conduct. For more information see the Code of Conduct FAQ or contact opencode@microsoft.com with any additional questions or comments.
